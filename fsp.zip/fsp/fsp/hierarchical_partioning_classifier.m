%Feature Space Partition structure

function [taxa_erro_total_OutSample, nova_data_teste, sort_nova_classe_teste, sort_nova_classe_teste_knn, sort_risk_value, sort_cauchy_value, sort_tr_tam_value, sort_tam_value, sort_prop_std, sort_prop_mean, sort_cel_idx]= hierarchical_partioning_classifier(C_final,historic,data_teste_in,classe_teste_in,p)

data_teste = data_teste_in;
classe_teste = classe_teste_in;

Prop1_cel_cong=NaN(1);
Prop2_cel_cong=NaN(1);
MClasse1_cel_cong=NaN(1);
MClasse2_cel_cong=NaN(1);
Data_tr_cel_cong={};
Classe_tr_cel_cong={};
i=0;
flag_primero=0;

for j=1:(length(historic)) 
    c_cong = historic(1, j).c_cong;
    if isempty(c_cong)
    else
        flag_primero=flag_primero+1;
        i=i+1;
        data_tr = historic(1, j).cell_cong_treino;
        classe_data_tr = historic(1, j).cell_cong_classe_treino;
        [lin_c,~] = size(c_cong);
        [qtd_obs,~] = size(data_tr);
        
        if lin_c==1
           ind = ones(qtd_obs,1);
        else
            distancias = dist(data_tr,c_cong');
            [~, ind]= min(distancias'); 
            ind = ind';
        end
        
        [Prop1_cel,Prop2_cel,MClasse1_cel,MClasse2_cel,~,data_cel,classe_cel]=info_cels(ind,lin_c,data_tr,classe_data_tr);
        
        if flag_primero == 1  
            Prop1_cel_cong = Prop1_cel;
            Prop2_cel_cong = Prop2_cel;
            MClasse1_cel_cong = MClasse1_cel;
            MClasse2_cel_cong = MClasse2_cel;
            Data_tr_cel_cong=data_cel;
            Classe_tr_cel_cong=classe_cel;
        else 
            Prop1_cel_cong = vertcat(Prop1_cel_cong,Prop1_cel);
            Prop2_cel_cong = vertcat(Prop2_cel_cong,Prop2_cel);
            MClasse1_cel_cong = vertcat(MClasse1_cel_cong,MClasse1_cel);
            MClasse2_cel_cong = vertcat(MClasse2_cel_cong,MClasse2_cel);
            Data_tr_cel_cong=vertcat(Data_tr_cel_cong,data_cel);
            Classe_tr_cel_cong=vertcat(Classe_tr_cel_cong,classe_cel);
        end
         
         centros_ite_cong{i} = historic(1, j).c_ite_cong;
         centros_cong{i} = historic(1, j).c_cong;
         
    end
end

%%%%%%%%%%%% Procedimento Selecionar C�lula Certa %%%%%%%%%%
[prototipo_k,~] = size(C_final);

cel_teste = cell(prototipo_k,1);
cel_classe_teste = cell(prototipo_k,1);
cel_classe_teste_knn = cell(prototipo_k,1);
cel_cauchy_value = cell(prototipo_k,1);
cel_tam_value = cell(prototipo_k,1);
cel_tr_tam_value = cell(prototipo_k,1);
cel_centro_valida = cell(prototipo_k,1);
cel_risk_value = cell(prototipo_k,1);
cel_prop_std = cell(prototipo_k,1);
cel_prop_mean = cell(prototipo_k,1);
cel_idx = cell(prototipo_k,1);
y=0;

for i=1:length(centros_ite_cong)
    C_ite_cong=centros_ite_cong{i};
    C_cong = centros_cong{i};
    
    [qtd_obs,~] = size(data_teste);
    [lin_C_ite_cong,~] = size(C_ite_cong);
    
    if lin_C_ite_cong==1
       ind = ones(qtd_obs,1);
    else
        distancias = dist(data_teste,C_ite_cong');
        [~, ind]= min(distancias'); 
        ind = ind';
    end
    
    valida_ind=zeros(length(C_ite_cong),1);
    [lin_C_cong,~] = size(C_cong);

    for x=1:lin_C_ite_cong  
        for z=1:lin_C_cong
            if (C_ite_cong(x,:)==C_cong(z,:))
                valida_ind(x)=1+valida_ind(x);   % flag que pega o indice aonde o centro fi 
            else
                valida_ind(x)=valida_ind(x);
            end
        end
    end
    
    for x=1:lin_C_ite_cong
        if valida_ind(x) == 1
            y=y+1;
            cel_teste{y}= data_teste(ind==x,:);
            cel_classe_teste{y}=classe_teste(ind==x,:);
            cel_centro_valida{y}=C_ite_cong(x,:);
        end
    end
    
    flag_primero=0;
    count_x=0;
    
    %Atualizar banco
     for x=1:length(C_ite_cong)
        if valida_ind(x) == 0
            flag_primero=1+flag_primero;
            if flag_primero == 1
                novo_data_teste = data_teste(ind==x,:);
                novo_classe_teste = classe_teste(ind==x,:);
            else
                novo_data_teste = vertcat(novo_data_teste,data_teste(ind==x,:));
                novo_classe_teste = vertcat(novo_classe_teste,classe_teste(ind==x,:));
            end
            count_x=1+count_x;
        end
     end 
     
     if count_x == 0
         novo_data_teste = data_teste;
         novo_classe_teste = classe_teste;
     end
     
     data_teste = novo_data_teste;
     classe_teste = novo_classe_teste;
end

%Classifica��o supervisionada

contador_erro= cell(prototipo_k);
contador_total= cell(prototipo_k);

for k= 1:prototipo_k
    if isempty(cel_teste{k})
        contador_erro{k}=0;
        contador_total{k}=1; %como o tamanho � zero, foi colocado isso apenas para nao ser NAN e n�o influenciar a taxa_error.
    else
        cel_teste_k=cel_teste{k};
        cel_classe_teste_k=cel_classe_teste{k};
        [max_vero,min_vero] = norm_vero_cel_k(cel_teste_k,MClasse1_cel_cong(k,:),MClasse2_cel_cong(k,:));
        [contador_t,contador_e,nova_cel_classe_teste,lrisk_value]= classif_supervisionada_convexo(1,Prop1_cel_cong(k),Prop2_cel_cong(k),MClasse1_cel_cong(k,:),MClasse2_cel_cong(k,:),cel_teste_k,cel_classe_teste_k,max_vero,min_vero,p);
        cel_classe_teste{k} = nova_cel_classe_teste;
        cel_risk_value{k} = lrisk_value;
        contador_erro{k}=contador_e;
        contador_total{k}=contador_t;
        
        data_tr_cel = Data_tr_cel_cong{k};
        class_tr_cel = Classe_tr_cel_cong{k};
        
        if (lrisk_value(1) > 0.7) && (lrisk_value(1) < 1-p)
            KNNModel = fitcknn(data_tr_cel,class_tr_cel,'NumNeighbors',floor(sqrt(numel(class_tr_cel)-1)));
            [class_knn,~] = predict(KNNModel,cel_teste_k);
            cel_classe_teste_knn{k} = class_knn;
        else
            cel_classe_teste_knn{k} = nova_cel_classe_teste;
        end
        
        dist_cauchy = cauchy_cel_treino_k(Data_tr_cel_cong{k},Classe_tr_cel_cong{k},false);
        cel_cauchy_value{k} = ones(numel(cel_classe_teste_k),1)*dist_cauchy;
        
        cel_tam_value{k} = ones(numel(cel_classe_teste_k),1)*numel(cel_classe_teste_k);
        cel_tr_tam_value{k} = ones(numel(cel_classe_teste_k),1)*numel(Classe_tr_cel_cong{k});
        
        if size(data_tr_cel,1) > 1
            [~,bootsam] = bootstrp(50,[],data_tr_cel);
            Prop1 = zeros(50,1);
            for n= 1:50       
                disp(size(class_tr_cel));
                disp(size(data_tr_cel));
                classe_treino_resample = class_tr_cel(bootsam(:,n),:);

                Prop1(n) = sum(classe_treino_resample==1)/numel(classe_treino_resample);
            end
        else
            Prop1 = 1;
        end
        
        cel_prop_std{k} = ones(numel(cel_classe_teste_k),1)*std(Prop1);
        cel_prop_mean{k} = ones(numel(cel_classe_teste_k),1)*mean(Prop1);
        cel_idx{k} = ones(numel(cel_classe_teste_k),1)*k;
    end
end

%%%%%%%%%%%%%%%%%% Calcula dos erros para cada c�lula %%%%%%%%%%%%%%%%%%

taxa_error = zeros(prototipo_k,1);

for k=1:prototipo_k
    taxa_error(k) = (contador_erro{k})/(contador_total{k});
end

%%%%% INFORMA��ES DE CADA C�LULA %%%%
tam_cel_teste = zeros(prototipo_k,1);

%CLASSIFICA��O
nova_classe_teste = vertcat(cel_classe_teste{:});
nova_classe_teste_knn = vertcat(cel_classe_teste_knn{:});

nova_data_teste = vertcat(cel_teste{:});

%CONFIAN�A E VALOR DE CAUCHY DE CADA C�LULA
risk_value = vertcat(cel_risk_value{:});
cauchy_value = vertcat(cel_cauchy_value{:});

%QTD DE DADOS DE TESTE E TREINO DE CADA C�LULA
tam_value = vertcat(cel_tam_value{:});
tr_tam_value = vertcat(cel_tr_tam_value{:});

%CONSIST�NCIA DA PROPOR��O DE CADA C�LULA
prop_std = vertcat(cel_prop_std{:});
prop_mean = vertcat(cel_prop_mean{:});

%ALGO PRA SABER DE QUE C�LULA EST� FALANDO
cel_idx_cat = vertcat(cel_idx{:});

sort_nova_classe_teste = nova_classe_teste;
sort_nova_classe_teste_knn = nova_classe_teste_knn;
sort_classe_teste = classe_teste_in;
sort_risk_value = risk_value;
sort_cauchy_value = cauchy_value;
sort_tam_value = tam_value;
sort_tr_tam_value = tr_tam_value;
sort_prop_std = prop_std;
sort_prop_mean = prop_mean;
sort_cel_idx = cel_idx_cat;

%%%%%%%% COLOCANDO NA ORDEM DE ENTRADA %%%%%%%%%%%%%%%%
for i=1:size(data_teste_in,1)
    for j=1:size(nova_data_teste,1)
        if sum(data_teste_in(i,:) == nova_data_teste(j,:)) == size(data_teste_in,2)
            sort_nova_classe_teste(i) = nova_classe_teste(j);
            sort_nova_classe_teste_knn(i) = nova_classe_teste_knn(j);
            sort_risk_value(i) = risk_value(j);
            sort_cauchy_value(i) = cauchy_value(j);
            sort_tam_value(i) = tam_value(j);
            sort_tr_tam_value(i) = tr_tam_value(j);
            sort_prop_std(i) = prop_std(j);
            sort_prop_mean(i) = prop_mean(j);
            sort_cel_idx(i) = cel_idx_cat(j);
        end
    end
end

for i=1:prototipo_k
    [linCel_teste, ~]= size(cel_teste{i});
    tam_cel_teste(i)=linCel_teste;
end

erro_total =0;
obs_total=0;

for i=1:prototipo_k
    erro_total = (tam_cel_teste(i)*taxa_error(i)) + erro_total;
    obs_total = tam_cel_teste(i)+obs_total;     
end
    
taxa_erro_total_OutSample = (erro_total)/(obs_total);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FIM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%