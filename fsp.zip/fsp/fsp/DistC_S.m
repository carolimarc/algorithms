function [D_C_S, DPtoCluster1, DPtoCluster2, Risco] = DistC_S(x, y, sigma, identity)

% rotina q implementa o conceito de dist de cauchy-schwarz entre duas
% densidades
% Parametros de Entrada:
% x - conjunto de dados
% y - label dos dados
% sigma - desvio padrao da normal
% Parametros de saida:
% D_C_S - dist de cauchy-schwarz entre duas densidades
% D_C_S = DG1 + DG2 + DCef, onde DG1 = -H(classe1) ; DG2 = -H(classe2) 
% (ambos sao o inverso da entropia da respectiva classe) e
% DCef = -2*log(CEF), CEF como definido no artigo Information Theoretic
% Clustering.
% DPtoCluster1 - vetor com a dist de cada observacao da classe 1 a
% densidade da classe 2
% DPtoCluster2 - vetor com a dist de cada observacao da classe 2 a
% densidade da classe 1
% Risco - observacoes q estao na zona de risco

% *************************************************************************

IndGrupo1 = find(y==1); % indices das obs da classe 1
IndGrupo2 = find(y==2); % indices das obs da classe 2

[n M] = size(x); % n = numero de observacoes; M = numero de atributos

Y = ones( length( x(:,1) ), 1 ); % vetor de 1's de tamanho = n (sera util para o produto de kronecker)
Y1 = ones( length( IndGrupo1 ), 1 ); % vetor de 1's de tamanho = qtde de obs da classe 1
Y2 = ones( length( IndGrupo2 ), 1 ); % vetor de 1's de tamanho = qtde de obs da classe 2


% M1 e M2 estao definidos de forma q: se M1(i)*M2(j) = 1, entao os indices
% i e j correspondem a observacoes de classes diferentes. Esta definicao e
% parecida com a do artigo Information Theoretic Clustering
M1(find(y==1)) =1; M1(find(y==2)) =0;
M2(find(y==1)) =0; M2(find(y==2)) =1;

parfor i=1:n
    % Potencial de informacao entre os 2 clusters
    % para evitar outro 'for', faco o prod de kron de x(i,:) por Y. Assim o
    % q seria o segundo for e feito de uma vez so.
    % o produto de M1(i) por M2 faz com q apenas as observacoes de classes
    % diferentes sejam consideradas.]
    if ~identity
        G(i) = sum((M1(i).*M2)'.*mvnpdf( kron(x(i,:),Y) - x ,zeros(1,length(x(1,:))),diag((sigma(:,1).^2)+(sigma(:,2).^2))));
        G_Aux(i) = sum((M2(i).*M1)'.*mvnpdf( kron(x(i,:),Y) - x ,zeros(1,length(x(1,:))),diag((sigma(:,1).^2)+(sigma(:,2).^2))));
        
        % Potencial de informacao do primeiro cluster
        G1(i) = sum(M1(i).*mvnpdf( kron(x(i,:),Y1) - x(IndGrupo1,:) ,zeros(1,length(x(1,:))),diag(2*(sigma(:,1).^2))));
        % Potencial de informacao do segundo cluster
        G2(i) = sum(M2(i).*mvnpdf( kron(x(i,:),Y2) - x(IndGrupo2,:) ,zeros(1,length(x(1,:))),diag(2*(sigma(:,2).^2))));
    else
        G(i) = sum((M1(i).*M2)'.*mvnpdf( kron(x(i,:),Y) - x ,zeros(1,length(x(1,:))),eye(length(x(1,:))) ));
        G_Aux(i) = sum((M2(i).*M1)'.*mvnpdf( kron(x(i,:),Y) - x ,zeros(1,length(x(1,:))),eye(length(x(1,:))) ));
        
        % Potencial de informacao do primeiro cluster
        G1(i) = sum(M1(i).*mvnpdf( kron(x(i,:),Y1) - x(IndGrupo1,:) ,zeros(1,length(x(1,:))),eye(length(x(1,:))) ));
        
        % Potencial de informacao do segundo cluster
        G2(i) = sum(M2(i).*mvnpdf( kron(x(i,:),Y2) - x(IndGrupo2,:) ,zeros(1,length(x(1,:))),eye(length(x(1,:))) ));
    end    
    % Note q G1 e G2 servem para calcular as entropias das classes 1 e 2.
end

% Distancia entre os clusters
Cef = (1/(length(IndGrupo1)*length(IndGrupo2)))*sum(G);
DCef = -2*log(Cef);

AuxG1 = (1/(length(IndGrupo1)^2))*sum(G1);
DG1 = log(AuxG1);

AuxG2 = (1/(length(IndGrupo2)^2))*sum(G2);
DG2 = log(AuxG2);

D_C_S = DG1 + DG2 + DCef;

% distancia pontual entre o cluster 1 e o cluster 2
D3 = -2*log( (1/(length(IndGrupo2))) * G(IndGrupo1) );

if ~identity
    D4 = log(mvnpdf( zeros(1,length(x(1,:))) ,zeros(1,length(x(1,:))),diag(2*(sigma(:,1).*sigma(:,1)))));
    D6 = log(mvnpdf( zeros(1,length(x(1,:))) ,zeros(1,length(x(1,:))),diag(2*(sigma(:,2).*sigma(:,2)))));
else
    D4 = log(mvnpdf( zeros(1,length(x(1,:))) ,zeros(1,length(x(1,:))),eye(length(x(1,:))) ));
    D6 = log(mvnpdf( zeros(1,length(x(1,:))) ,zeros(1,length(x(1,:))),eye(length(x(1,:))) ));
end

DPtoCluster1 = D3 + kron(D4,Y1)' + kron(DG2,Y1)';

% distancia pontual entre o cluster 2 e o cluster 1
D5 = -2*log( (1/(length(IndGrupo1))) * G_Aux(IndGrupo2) );

DPtoCluster2 = kron(D6,Y2)' + D5 + kron(DG1,Y2)';

%zona_risco1 = find((DPtoCluster1./(D_C_S^2)) < 1);
%zona_risco2 = find((DPtoCluster2./(D_C_S^2)) < 1);

zona_risco1 = find((DPtoCluster1./(3*D_C_S)) < 1);
zona_risco2 = find((DPtoCluster2./(3*D_C_S)) < 1);

Risco = [IndGrupo1(zona_risco1)' IndGrupo2(zona_risco2)'];


% distancia pontual entre o cluster 1 e ele mesmo
%D7 = -2*log( (1/(length(IndGrupo1))) * G1(IndGrupo1) );

%DPtoCluster1_1 = D7 + kron(D4,Y1)' + kron(DG1,Y1)';

% distancia pontual entre o cluster 2 e ele mesmo
%D8 = -2*log( (1/(length(IndGrupo2))) * G2(IndGrupo2) );

%DPtoCluster2_2 = kron(D6,Y2)' + D8 + kron(DG2,Y2)';

% EliminadosGrupo1 = IndGrupo1(zona_risco1(find((DPtoCluster1(zona_risco1)./DPtoCluster1_1(zona_risco1)) < 1)));
% EliminadosGrupo2 = IndGrupo2(zona_risco2(find((DPtoCluster2(zona_risco2)./DPtoCluster2_2(zona_risco2)) < 1)));

%%EliminadosGrupo1 = IndGrupo1(DPtoCluster1./DPtoCluster1_1 > 3);
%%EliminadosGrupo2 = IndGrupo2(DPtoCluster2./DPtoCluster2_2 > 3);

%Risco = setdiff(Risco, [EliminadosGrupo1' EliminadosGrupo2']);
%%Risco = [EliminadosGrupo1' EliminadosGrupo2'];