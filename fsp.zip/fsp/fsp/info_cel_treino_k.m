function [Prop1,Prop2,MClasse1,MClasse2]= info_cel_treino_k(cel_treino,cel_classe_treino)
%DEFINI��O: info_cel_treino_k � uma fun��o que calcula os centros e a propor��o de cada classe em uma c�lula treino. Aplic�vel somente em R2

%INPUT:
  % Celula de treino e classe da celula de treino de entrada
  
%OUTPUT: 
  % Centro euclidiano classe 1 celula treino: MClasse1
  % Centro euclidiano classe 2 celula treino: MClasse2
  % Propor��o classe 1 celula treino: Prop1
  % Propor��o classe 2 celula treino: Prop2


%Inicializa��o Par�metros
cel_treino1 = cel_treino(cel_classe_treino==1,:); 
cel_treino2 = cel_treino(cel_classe_treino==2,:); 
            
[linCel, ~]= size(cel_treino);   
[linCel1, ~]= size(cel_treino1);
[linCel2, ~]= size(cel_treino2);
  
Prop1 = (linCel1/linCel); % propor��o classe 1
Prop2 = (linCel2/linCel); % propor��o classe 2

MClasse1 = (sum(cel_treino1))/(linCel1); %calcula centro dbserva��es de classe 1 
MClasse2 = (sum(cel_treino2))/(linCel2); %calcula o centro das observa��es de classe 2 

if linCel1 == 1 %h� somente uma observa��o com classe = 1 pertencente nesse c�lula 
    MClasse1 = cel_treino1 + 0.01; %centro da classe 1 � igual a observa��o nesse ponto + uma pequena pertuba��o para evitar max verossimilhan�a. 
end;

if linCel2 == 1 %h� somente uma observa��o com classe = 2 pertencente nesse c�lula
    MClasse2 = cel_treino2 + 0.01; %centro da classe 2 � igual a observa��o nesse ponto + uma pequena pertuba��o para evitar max verossimilhan�a.
end;

end

