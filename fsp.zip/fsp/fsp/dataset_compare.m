%% Pedreira, E. and Marcelino, C.
% Feature Space Partition algorithm
% To run in a power full computer (with 64GB ram or more)

clear;
close all;
clc;

distcomp.feature('LocalUseMpiexec', false);
leave_1_out = false;

leave_1_out_names = {'heart'};
k_fold_names = {'bands', 'bupa ','heberman'}; %'bc_diagnosis'

for leave_1_out = 0:1
    disp(['Leave 1 out:' num2str(leave_1_out)]);

%%%%%%%%%%%%%%%%%%%%%%%%% only k-fold    
    if leave_1_out
        names = k_fold_names;
    else
        names = k_fold_names;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    for item=names
        name = item{1};
        disp(name)

        %TRAIN
        load_data = load(['.\data\' name '_dataset.mat']);
        field_names = fieldnames(load_data);

        matches = strfind(field_names, 'classe');
        class_pos = find(~cellfun('isempty',matches));

        matches = strfind(field_names, 'data');
        data_pos = find(~cellfun('isempty',matches));

        train_data = load_data.(field_names{data_pos});
        train_class = load_data.(field_names{class_pos});

        separability_param = 0.5;
        homogeneity_param = 0.05;

        Nt_data = numel(train_class);
        predict_error_hpa = [];
        predict_error_homo_hpa = [];
        predict_error_hete_hpa = [];

        predict_error_svm = [];
        predict_error_homo_svm = [];
        predict_error_hete_svm = [];

        predict_error_knn = [];
        predict_error_homo_knn = [];
        predict_error_hete_knn = [];

        if leave_1_out
            for i=1:Nt_data
                disp(i);
                train_idx = setdiff(1:Nt_data,i);
                test_idx = i;

                [C_final_k,history_k,~]= train_hierarchical_partioning_classifier(homogeneity_param,...
                                                                                        train_data(train_idx,:),...
                                                                                        train_class(train_idx),...
                                                                                        separability_param,...
                                                                                        false);

                [~, ~, class_test_hpa, ~, prop_value, ~, ~, ~, ~, ~] = hierarchical_partioning_classifier(C_final_k,...
                                                                                 history_k,...
                                                                                 train_data(test_idx,:),...
                                                                                 train_class(test_idx),...
                                                                                 homogeneity_param);

                KNNModel = fitcknn(train_data(train_idx,:),train_class(train_idx,:),'NumNeighbors', round(rand(1)*4)+2);
                SVMModel = fitcsvm(train_data(train_idx,:),train_class(train_idx,:),'KernelFunction','linear');

                [class_test_svm,~] = predict(SVMModel,train_data(test_idx,:));
                [class_test_knn,~] = predict(KNNModel,train_data(test_idx,:));

                if prop_value >= (1-homogeneity_param)
                    predict_error_homo_hpa = [predict_error_homo_hpa class_test_hpa(1)~=train_class(test_idx)];
                    predict_error_homo_svm = [predict_error_homo_svm class_test_svm(1)~=train_class(test_idx)];
                    predict_error_homo_knn = [predict_error_homo_knn class_test_knn(1)~=train_class(test_idx)];
                else
                    predict_error_hete_hpa = [predict_error_hete_hpa class_test_hpa(1)~=train_class(test_idx)];
                    predict_error_hete_svm = [predict_error_hete_svm class_test_svm(1)~=train_class(test_idx)];
                    predict_error_hete_knn = [predict_error_hete_knn class_test_knn(1)~=train_class(test_idx)];
                end

                predict_error_hpa = [predict_error_hpa class_test_hpa(1)~=train_class(test_idx)];
                predict_error_svm = [predict_error_svm class_test_svm(1)~=train_class(test_idx)];
                predict_error_knn = [predict_error_knn class_test_knn(1)~=train_class(test_idx)];
            end
        else
            cv_parts = cvpartition(train_class, 'KFold', 10);

            for i=1:10 
                test_idx = cv_parts.test(i);
                train_idx = cv_parts.training(i);

                [C_final_k,history_k,~]= train_hierarchical_partioning_classifier(homogeneity_param,...
                                                                            train_data(train_idx,:),...
                                                                            train_class(train_idx),...
                                                                            separability_param,...
                                                                            false);

                [~, ~, class_test_hpa, ~, prop_value, ~, ~, ~, ~, ~] = hierarchical_partioning_classifier(C_final_k,...
                                                                                 history_k,...
                                                                                 train_data(test_idx,:),...
                                                                                 train_class(test_idx),...
                                                                                 homogeneity_param);                                                                     

                                                                             
                KNNModel = fitcknn(train_data(train_idx,:),train_class(train_idx,:),'NumNeighbors',round(rand(1)*4)+2);
                SVMModel = fitcsvm(train_data(train_idx,:),train_class(train_idx,:),'KernelFunction','linear');

                [class_test_svm,~] = predict(SVMModel,train_data(test_idx,:));
                [class_test_knn,~] = predict(KNNModel,train_data(test_idx,:));

                test_class_k = train_class(test_idx);
                test_homo_class = test_class_k(prop_value >= (1-homogeneity_param));
                test_hete_class = test_class_k(prop_value < (1-homogeneity_param));

                test_data_k = train_data(test_idx,:);
                test_homo_data = test_data_k(prop_value >= (1-homogeneity_param),:);
                test_hete_data = test_data_k(prop_value < (1-homogeneity_param),:);

                predict_error_homo_hpa = [predict_error_homo_hpa mean(class_test_hpa(prop_value >= (1-homogeneity_param))~=test_homo_class)];
                predict_error_homo_svm = [predict_error_homo_svm mean(class_test_svm(prop_value >= (1-homogeneity_param))~=test_homo_class)];
                predict_error_homo_knn = [predict_error_homo_knn mean(class_test_knn(prop_value >= (1-homogeneity_param))~=test_homo_class)];
                predict_error_hete_hpa = [predict_error_hete_hpa mean(class_test_hpa(prop_value < (1-homogeneity_param))~=test_hete_class)];           
                predict_error_hete_svm = [predict_error_hete_svm mean(class_test_svm(prop_value < (1-homogeneity_param))~=test_hete_class)];           
                predict_error_hete_knn = [predict_error_hete_knn mean(class_test_knn(prop_value < (1-homogeneity_param))~=test_hete_class)];
                predict_error_hpa = [predict_error_hpa mean(class_test_hpa~=train_class(test_idx))];            
                predict_error_svm = [predict_error_svm mean(class_test_svm~=train_class(test_idx))];           
                predict_error_knn = [predict_error_knn mean(class_test_knn~=train_class(test_idx))];
                predict_error_knn_svmhete = mean(mean(predict_error_hpa) + mean(predict_error_hete_svm));
             
            end
        end
        predict_error_hpa = mean(predict_error_hpa);
        spredict_error_hpa = std(predict_error_hpa);
        predict_error_svm = mean(predict_error_svm);
        spredict_error_svm = std(predict_error_svm);
        predict_error_knn = mean(predict_error_knn);
        spredict_error_knn = std(predict_error_knn);

        predict_error_homo_hpa = mean(predict_error_homo_hpa);
        spredict_error_homo_hpa = std(predict_error_homo_hpa);
        predict_error_homo_svm = mean(predict_error_homo_svm);
        spredict_error_homo_svm = std(predict_error_homo_svm);
        predict_error_homo_knn = mean(predict_error_homo_knn);
        spredict_error_homo_knn = std(predict_error_homo_knn);

        predict_error_hete_hpa = mean(predict_error_hete_hpa);
        spredict_error_hete_hpa = std(predict_error_hete_hpa);
        predict_error_hete_svm = mean(predict_error_hete_svm);
        spredict_error_hete_svm = std(predict_error_hete_svm);
        predict_error_hete_knn = mean(predict_error_hete_knn);
        spredict_error_hete_knn = std(predict_error_hete_knn);
        

        predict_error_knnhomo_svmhete = mean(predict_error_knn_svmhete);

        fileID = fopen(['./data/' name(1:numel(name)-4) '_out.txt'],'w');

        fprintf(fileID,'%s\r\n',name);
        fprintf(fileID,'%s\r\n',['HPA Outsample Error (mean): ' num2str(predict_error_hpa)]);
        fprintf(fileID,'%s\r\n',['SVM Outsample Error (mean): ' num2str(predict_error_svm)]);
        fprintf(fileID,'%s\r\n',['KNN Outsample Error (mean): ' num2str(predict_error_knn)]);
        fprintf(fileID,'%s\r\n','');
        fprintf(fileID,'%s\r\n',['HPA Homogeneous Outsample Error (mean): ' num2str(predict_error_homo_hpa)]);
        fprintf(fileID,'%s\r\n',['SVM Homogeneous Outsample Error (mean): ' num2str(predict_error_homo_svm)]);
        fprintf(fileID,'%s\r\n',['KNN Homogeneous Outsample Error (mean): ' num2str(predict_error_homo_knn)]);
        fprintf(fileID,'%s\r\n','');
        fprintf(fileID,'%s\r\n',['HPA Heterogeneous Outsample Error (mean): ' num2str(predict_error_hete_hpa)]);
        fprintf(fileID,'%s\r\n',['SVM Heterogeneous Outsample Error (mean): ' num2str(predict_error_hete_svm)]);
        fprintf(fileID,'%s\r\n',['KNN Heterogeneous Outsample Error (mean): ' num2str(predict_error_hete_knn)]);
        fprintf(fileID,'%s\r\n',['Merge KNN-Homo and SVM-Hete: ' num2str(predict_error_knnhomo_svmhete)]);
        fprintf(fileID,'%s\r\n','');
        fprintf(fileID,'%s\r\n','');
        fclose(fileID);
    end
end
