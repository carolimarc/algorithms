function [Prop1_cel,Prop2_cel,MClasse1_cel,MClasse2_cel,tam_cel,data_cel,classe_cel]=info_cels(IDX,prototipo_k,data_treino,classe_treino)

%DEFINI��O: info_cels � uma fun��o que calcula os par�metros de todas as c�lulas treino, incluindo o tamanho de cada, ou seja, quantidade de observa��es treino. Aplic�vel somente em R2

%INPUT:
    % Celula de teste matriz: cel_teste
%OUTPUT: 
    % Centro euclidiano classe 1 celula treino: MClasse1
    % Centro euclidiano classe 2 celula treino: MClasse2
 
%Inicializa��o Par�metros

[~, col_treino]= size(data_treino);

MClasse1_cel = zeros(prototipo_k,col_treino);
MClasse2_cel = zeros(prototipo_k,col_treino);
Prop1_cel = zeros(prototipo_k,1);
Prop2_cel = zeros(prototipo_k,1);
tam_cel = zeros(prototipo_k,1);
data_cel = cell(prototipo_k,1);
classe_cel = cell(prototipo_k,1);

for i=1:prototipo_k
    
            cel = data_treino(IDX==i,:); %celula que a nova observa��o caiu
            cel1 = data_treino(classe_treino==1 & IDX==i,:); %conjunto de observacoes do treino da classe 1 que pertencem a celula que a nova observa��o caiu
            cel2 = data_treino(classe_treino==2 & IDX==i,:); %conjunto de observacoes do treino da classe 2 que pertencem a celula que a nova observa��o caiu
            
            data_cel{i} = cel;
            classe_cel{i} = classe_treino(IDX==i);
            
            [linCel, ~]= size(cel);   
            [linCel1, ~]= size(cel1);
            [linCel2, ~]= size(cel2);
  
            tam_cel(i,1)=linCel;

            Prop1_cel(i,1) = (linCel1/linCel); % propor��o classe 1
            Prop2_cel(i,1) = (linCel2/linCel); % propor��o classe 2

            MClasse1_cel(i,:) = (sum(cel1))/(linCel1); %calcula centro dbserva��es de classe 1 
            MClasse2_cel(i,:) = (sum(cel2))/(linCel2); %calcula o centro das observa��es de classe 2 

            if linCel1 == 1 %h� somente uma observa��o com classe = 1 pertencente nesse c�lula 
                MClasse1_cel(i,:) = cel1 + 0.01; %centro da classe 1 � igual a observa��o nesse ponto + perturba��o. 
            end
            if linCel2 == 1 %h� somente uma observa��o com classe = 2 pertencente nesse c�lula 
                MClasse2_cel(i,:) = cel2 + 0.01; %centro da classe 2 � igual a observa��o nesse ponto + perturba��o.
            end
end
end