function [dist_cauchy]= cauchy_cel_treino_k(cel_treino,cel_classe_treino,identity)
%DEFINI��O: 

%INPUT:
  % Celula de treino e classe da celula de treino de entrada
  
%OUTPUT: 

cel_treino1 = cel_treino(cel_classe_treino==1,:); 
cel_treino2 = cel_treino(cel_classe_treino==2,:); 

[linCel1, d]= size(cel_treino1); 
[linCel2, ~]= size(cel_treino2);

if linCel1 <= 2 || linCel2 <= 2
    dist_cauchy = 0;
else
    std1 = std(cel_treino1);
    std1 = std1*((4/((d+2)*linCel1))^(1/(d+4)));
    std1 = std1 + (std1==0)*0.00001;

    std2 = std(cel_treino2);
    std2 = std2*((4/((d+2)*linCel2))^(1/(d+4)));
    std2 = std2 + (std2==0)*0.00001;
    
    sigma = [std1' std2'];    
    
    [D_C_S, DPtoCluster1, DPtoCluster2, Risco] = DistC_S(cel_treino, cel_classe_treino, sigma, identity);
    dist_cauchy = D_C_S;
end
%disp(dist_cauchy);