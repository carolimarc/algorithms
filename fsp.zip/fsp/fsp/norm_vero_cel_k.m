function [max_vero,min_vero]= norm_vero_cel_k(cel_teste,MClasse1,MClasse2)
%DEFINI��O: norm_vero_cel_k � uma fun��o que calcula a m�xima e m�nima verossimilhan�a para cada celula teste a partir dos centros de classe de uma c�lula treino. Aplic�vel somente em R2

%INPUT:
    % Centro euclidiano classe 1 celula treino: MClasse1
    % Centro euclidiano classe 2 celula treino: MClasse2
    % Celula de teste matriz: cel_teste
%OUTPUT: 
    % M�xima verossimilhan�a encontrada: max_vero
    % M�nima verossimilhan�a encontrada: min_vero
 
%Inicializa��o Par�metros

[lin_cel_teste, ~]= size(cel_teste);
vero1 = zeros(lin_cel_teste,1);
vero2 = zeros(lin_cel_teste,1);

if (isnan(MClasse1)~=1) & (isnan(MClasse2)~=1)
    
    for i=1:lin_cel_teste
        distancias_classe(1,:) = dist(cel_teste(i,:),MClasse1'); %distancia da observa��o do data_teste para cada centro de classe = 1 dentro de cada celula. 
        distancias_classe(2,:) = dist(cel_teste(i,:),MClasse2'); %distancia da observa��o do data_teste para cada centro de classe = 1 dentro de cada celula
        vero1(i) = (1/distancias_classe(1,:)); %verossimilhan�a da classe = 1 
        vero2(i) = (1/distancias_classe(2,:)); %verossimilhan�a da classe = 2 
    end

    max_vero_classe1 = max(vero1);
    max_vero_classe2 = max(vero2);
    min_vero_classe1 = min(vero1);
    min_vero_classe2 = min(vero2);
    max_vero = max(max_vero_classe1, max_vero_classe2);
    min_vero = min(min_vero_classe1, min_vero_classe2);

else   
    max_vero=1;
    min_vero=0;
end
 
    
    
    
    
    
    
end

