function [ erro_min_value, q_min_values, q_interv2, erro_interv2 ] = classif_sb(IDX,K,data_teste,data_treino,classe_treino,classe_teste,C,p)
%fun��o de classifica��o sem bootstrap
%LOG: epsilon calculo erro do intervalo


[qtd_obs, ~]= size(data_treino);

qtd_q=11;
if K==1
    ind = ones(qtd_obs,1);
else
distancias = dist(data_teste,C');
[~, ind]= min(distancias'); 
ind = ind';
end

%Separa��o dos dados e classes em c�lulas 
cel_treino = cell(K,1);
cel_teste = cell(K,1);
cel_classe_treino = cell(K,1);
cel_classe_teste = cell(K,1);

for i=1:K 
    cel_treino{i}= data_treino(IDX==i,:);
    cel_teste{i}= data_teste(ind==i,:);
    cel_classe_treino{i}=classe_treino(IDX==i,:);
    cel_classe_teste{i}=classe_teste(ind==i,:); 
end

%Classifica��o supervisionada sem bootstrap

j=1;
contador_erro= cell(qtd_q,K);
contador_total= cell(qtd_q,K);

for q = 0:0.1:1
    for k= 1:K
        cel_treino_k=cel_treino{k};
        cel_teste_k=cel_teste{k};
        cel_classe_treino_k=cel_classe_treino{k};
        cel_classe_teste_k=cel_classe_teste{k};
        [lin_treino, ~] = size(cel_treino_k);
        if (lin_treino >1) %celula com 1 observa��o � tratada direto com erro =0 
            [Prop1,Prop2,MClasse1,MClasse2] = info_cel_treino_k(cel_treino_k,cel_classe_treino_k);
            [max_vero,min_vero] = norm_vero_cel_k(cel_teste_k,MClasse1,MClasse2);
            q=1; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% mudan�a para levar em conta somente propor��o.
            [contador_t,contador_e,nova_cel_classe_teste,risk_value]= classif_supervisionada_convexo(q,Prop1,Prop2,MClasse1,MClasse2,cel_teste_k,cel_classe_teste_k,max_vero,min_vero,p);
            contador_erro{j,k}=contador_e;
            contador_total{j,k}=contador_t;     
        else
            contador_erro{j,k}=0;
            contador_total{j,k}=1;
        end
    end
    j=j+1;
end     

%%%%%%%%%%%%%%%%%% Calcula dos erros para cada c�lula e cada Q.

qtd_q=11;
taxa_error = zeros(qtd_q,K);

for j = 1:qtd_q
    for k=1:K
        taxa_error(j,k) = (contador_erro{j,k})/(contador_total{j,k});
    end
end

%%%%%%%%%%%%%%%%%%% Achando Q correspondendo ao erro m�nimo para cada c�lula

q_min_indice = zeros(K,1);
erro_min_value = zeros(K,1);

for i=1:K
    erro_min_value(i) = min(taxa_error(:,i));
    q_min_indice(i) = find (taxa_error(:,i) == min(taxa_error(:,i)),1,'first');
end

q_min_values = changem(q_min_indice,[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1],[1 2 3 4 5 6 7 8 9 10 11]);

% Achando INTERVADO de Q para cada c�lula
epislon=0;
erro_interv = zeros(qtd_q,K);
erro_interv2 = zeros(2,K);
q_interv = zeros(qtd_q,K);
q_interv2 = zeros(2,K);

for i=1:K
    for j=1:qtd_q
        if ((taxa_error(j,i) <= erro_min_value(i) + epislon) || (taxa_error(j,i) == erro_min_value(i)))
            erro_interv(j,i)=taxa_error(j,i);
            q_interv(j,i)= j;
        else
            erro_interv(j,i)=NaN(1);
            q_interv(j,i)= NaN(1);
        end
    end
end

for i=1:K
    erro_interv2(1,i) = max(erro_interv(:,i));
    erro_interv2(2,i) = min(erro_interv(:,i));
end

for i=1:K
    q_interv2(1,i) = max(q_interv(:,i));
    q_interv2(2,i) = min(q_interv(:,i));
end

q_interv2 = changem(q_interv2,[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1],[1 2 3 4 5 6 7 8 9 10 11]);

%%%%%%%%%%% FIM %%%%%%%%%

end

