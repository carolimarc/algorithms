function [C_final,hist,taxa_erro_total_Insample]= train_hierarchical_partioning_classifier (p,data_treino,classe_treino,limiar_cauchy,identity)

[lin,~] = size(data_treino);
P=lin;
S_cong=0;

% CONDI��ES INICIAIS ALGORITMO
parou = 0;
cond=1;
cond_max=2000;
K=1;
congela=0;
C_cong = cell(cond_max-1,1);
q_interv_cong = cell(cond_max-1,1);
C_final=NaN(1);
C_final_class=NaN(1);
q_interv_final=NaN(1);
erro_min_final=NaN(1);
hist = struct('ite_class',{},'ite_data',{},'lcauchy',0,'p',0,'K',0,'erro_media_pond',0,'qtd_congelado',0,'flag_erro',{},'erro_min',0,'tam_cel',0,'q_min',0,'Cauchy_K',{},'Prop2_K_boot',{},'Prop1_K_boot',{}, 'c_cong',{},'cell_cong_treino',{},'cell_cong_classe_treino',{},'q_interv',{},'erro_interv',{},'c_ite_cong',{},'c_ite_valid',{});
hist(1).K=K;
hist(1).p=p;

while cond < cond_max
    separavel = 1;
    while separavel==1
        hist(cond).ite_class = classe_treino;
        hist(cond).ite_data = data_treino;
        
        flag_primero=0;
        init=0;
        qtd_congelado=0;
        erro_interv2_cong=0;
        q_interv2_cong=0;
        bootstrap=1;
        flag_erro=zeros(1,K);

        
        %%% APPROACH LOCAL/N�O SUPERVISIONADO %%%
        %disp('K-means...');
        [IDX,C] = kmeans(data_treino,K,'emptyaction','singleton');
        IDX = IDX';
        Prot = struct('indices', 0);
        for z=1:K
            Prot(z).indices = find(IDX == z);                                          
        end 
        IDX = IDX';
        hist(cond).c_ite_valid = C;
        
        %%%% CLASSIFICA��O SUPERVISIONADA %%%%
        [erro_min_value, q_min_values, q_interv2, erro_interv2] = classif_sb(IDX,K,data_treino,data_treino,classe_treino,classe_treino,C,p);
        
        %%% GERAR ERRO M�DIO PONDERADO DE TODAS AS C�LULAS - TESTE HOMOGENEIDADE %%%
        S=S_cong;
        
        %AQUI A GENTE FAZ O LUCIANO E O NILTON MORDER A L�NGUA

        [Prop1_cel,Prop2_cel,MClasse1_cel,MClasse2_cel,tam_cel,~,~]=info_cels(IDX,K,data_treino,classe_treino); %% VER SE PROP1_CEL E PROP2_CEL TA BATENDO COM ERRO MIN VALUE E SE TAMANHOS ESTAO CERTOS 
        
        [lin,~] = size(C);%% INCLUIR TESTE PARA VER SE A CELULA N ESTA VAZIA 
        for i = 1:lin
            S = erro_min_value(i)*tam_cel(i) + S;
        end
        erro_media_pond=S/P;

        hist(cond).erro_media_pond = erro_media_pond;
        hist(cond).tam_cel = tam_cel;
        %%%%%%
        
        
        %%%%%% VERIFICACAO SE ALGUMA CELULA CONGELOU %%%%%%%%
        [lin,~] = size(C);
        for i = 1:lin
            if (erro_min_value(i) <= p) %celula congelou
                flag_primero=1+flag_primero;
                qtd_congelado=qtd_congelado+1;
                flag_erro(i)=1;
                if flag_primero == 1
                    init = i;
                    hist_erro = erro_min_value(i);
                    hist_q_min = q_min_values(i);
                else
                    init = [init,i];
                    hist_erro = [hist_erro,erro_min_value(i)];
                    hist_q_min= [q_min_values(i),hist_q_min];
                end
            end 
        end
        
        hist(cond).flag_erro = flag_erro;
        
        if qtd_congelado == 0 %se nenhuma celula for congelada  
            hist(cond).qtd_congelado=0;
            
            %%% TESTE DE CONSIST�NCIA COM BOOTSTRAP %%%%
            Prop1_K_boot=zeros(K,1);
            Prop2_K_boot=zeros(K,1);

            Dist_cauchy_K_boot=zeros(K,1);
                
            %Separa��o dos dados e classes em c�lulas 
            [qtd_obs, ~]= size(data_treino);

            if K==1
                ind = ones(qtd_obs,1);
            else
                distancias = dist(data_treino,C');
                [~, ind]= min(distancias'); 
                ind = ind';
            end

            cel_treino = cell(K,1);
            cel_classe_treino = cell(K,1);

            for i=1:K 
                cel_treino{i}= data_treino(ind==i,:);
                cel_classe_treino{i}=classe_treino(ind==i,:);
            end

            %Guarda propor��o e cauchy de cada c�lula para cada bootstrap
            for i=1:K
                cel_treino_k=cel_treino{i};
                cel_classe_treino_k=cel_classe_treino{i};

                [dist_cauchy]= cauchy_cel_treino_k(cel_treino_k,cel_classe_treino_k,identity);
                if size(cel_treino_k,1) > 1
                    Dist_cauchy_K_boot(i) = dist_cauchy;
                else
                    Dist_cauchy_K_boot(i) = 0;
                end

                [Prop1,Prop2,MClasse1,MClasse2] = info_cel_treino_k(cel_treino_k,cel_classe_treino_k);
                Prop1_K_boot(i) = Prop1;
                Prop2_K_boot(i) = Prop2;    
            end    

            hist(cond).Prop1_K_boot =Prop1_K_boot;
            hist(cond).Prop2_K_boot =Prop2_K_boot;
            hist(cond).Cauchy_K = Dist_cauchy_K_boot;

            %atualiza limiar baseado no erro

            if cond ~= 1
                if hist(cond-1).erro_media_pond ~= 0
                    delta_erro_perc = (erro_media_pond)/(hist(cond-1).erro_media_pond);
                    limiar_cauchy = limiar_cauchy/sqrt(delta_erro_perc);
                end
            end

            hist(cond).lcauchy = limiar_cauchy;
            count_cauchy=0;
            
            for i=1:K
                if Dist_cauchy_K_boot(i) >= limiar_cauchy
                    count_cauchy = count_cauchy + 1;
                end
            end

            
            if count_cauchy~=0
                separavel = 1;
                
                hist(cond).erro_min=[];
                hist(cond).q_min=[];
                hist(cond).qtd_congelado=0;
                q_interv_cong{cond} = [];
                hist(cond).q_interv=q_interv_cong{cond};
                hist(cond).erro_interv=[];
                hist(cond).c_ite_cong=[];
                
                C_cong{cond} = [];
                hist(cond).c_cong = C_cong{cond};
                q_interv_cong{cond} = [];
                
                K = K+1;
                
                [lin, ~] = size(data_treino);
                if K >= lin  % K n pode ser maior que o numero de observacoes no conjunto treino
                    K=lin;
                end
                
                %Atualiza vari�veis
                cond=cond+1;
                hist(cond).K=K;
                hist(cond).p=p;
                congela=0;
                
            else
                separavel = 0;
                
                %Atualiza hist     
                flag_primero=0;

                [lin,~] = size(C);
                for i = 1:lin
                        flag_primero=1+flag_primero;
                        if flag_primero == 1
                            hist_erro = erro_min_value(i);
                        else
                            hist_erro = [hist_erro,erro_min_value(i)];
                        end
                end

                hist(cond).erro_min=hist_erro;
                hist(cond).K=K;
                hist(cond).c_cong =C;
                hist(cond).c_ite_cong=C;
                hist(cond).cell_cong_treino = data_treino;
                hist(cond).cell_cong_classe_treino = classe_treino;
                hist(cond).qtd_congelado=0;
                hist(cond).p=p;

                %FIM do Algoritmo
                parou = cond;
                cond = cond_max;
            end
        else
            separavel = 1;
            
            hist(cond).erro_min=hist_erro;
            hist(cond).q_min=hist_q_min;
            hist(cond).qtd_congelado=qtd_congelado;  %gravar quantidade de celulas congeladas naquela itera��o
            q_interv_cong{cond} = q_interv2(:,init);
            hist(cond).q_interv=q_interv_cong{cond};
            hist(cond).erro_interv=[];
            hist(cond).c_ite_cong=C;
            
            [qtd_obs, ~]= size(data_treino);

            if K==1
                ind = ones(qtd_obs,1);
            else
                distancias = dist(data_treino,C');
                [~, ind]= min(distancias'); 
                ind = ind';
            end

            cel_treino = cell(K,1);
            cel_classe_treino = cell(K,1);

            for i=1:K 
                cel_treino{i}= data_treino(ind==i,:);
                cel_classe_treino{i}=classe_treino(ind==i,:);
            end
            
            Prop1_K_boot=zeros(K,1);
            Prop2_K_boot=zeros(K,1);
            
            for i=1:K
                cel_treino_k=cel_treino{i};
                cel_classe_treino_k=cel_classe_treino{i};

                [Prop1,Prop2,MClasse1,MClasse2] = info_cel_treino_k(cel_treino_k,cel_classe_treino_k);
                Prop1_K_boot(i) = Prop1;
                Prop2_K_boot(i) = Prop2;    
            end
            
            hist(cond).Prop1_K_boot =Prop1_K_boot;
            hist(cond).Prop2_K_boot =Prop2_K_boot;
            
            if mean(data_treino) == C(1,:) % condi��o se c�lula congelada = base de treino i.e. centr�ide = m�dia dos dados 
                C_cong{cond} = C;
                hist(cond).c_cong = C_cong{cond};
                q_interv2_cong = q_interv_cong{cond}; %linha = celula; coluna 1 = maximo ; coluna 2= min
                erro_interv2_cong=erro_interv2(:,init); %linha = celula; coluna 1 = maximo ; coluna 2= min
                C_figura = C(init,:);
            else
                C_cong{cond} = C(init,:);
                C_figura = C(init,:);
                hist(cond).c_cong = C_cong{cond};
                q_interv2_cong = q_interv_cong{cond}; %linha = celula; coluna 1 = maximo ; coluna 2= min
                erro_interv2_cong=erro_interv2(:,init); %linha = celula; coluna 1 = maximo ; coluna 2= min
            end
            
            %ANTES DE ATUALIZAR BASE DE DADOS, CALCULA S_CONG PARA CALCULO DO
            %ERRO MEDIO PONDERADO TOTAL

            C_cong_S = hist(cond).c_cong;
            C_total_S = hist(cond).c_ite_cong;

            [lin_total,~] = size(C_total_S);
            [lin_cong,~] = size(C_cong_S);

            indice_cong_S = zeros(lin_total,1);

            for Si = 1:lin_total
                for Sj = 1:lin_cong
                    if C_total_S(Si,:) == C_cong_S(Sj,:)
                        indice_cong_S(Si) = 1;
                    end
                end
            end

            for i=1:lin_total
                if indice_cong_S(i)==1
                    S_cong = S_cong + erro_min_value(i)*tam_cel(i);
                end
            end

            %Atualiza base de dados
            [~, col] = size(init);
            for i = 1:col
                if congela == 0
                    congela = Prot(1,init(i)).indices;
                else
                    congela = horzcat(Prot(1,init(i)).indices,congela);
                end
            end
            %Armazena e deleta do dataset observa��es congeladas
            hist(cond).cell_cong_treino = data_treino(congela,:);
            hist(cond).cell_cong_classe_treino = classe_treino(congela,:);
            data_treino(congela,:) = [];
            classe_treino(congela,:) = [];
            
            K = 1;
            
            %Atualiza vari�veis
            cond=cond+1;
            hist(cond).K=K;
            hist(cond).p=p;
            congela=0;   
            if cond == cond_max
                disp('FUCK');
            end
            
            [lin, ~] = size(data_treino);
            if lin == 0
                disp('NO OBS');
                %Atualiza hist
                hist(cond).erro_min=[];
                hist(cond).K=[];
                hist(cond).c_cong =[];
                hist(cond).c_ite_cong=[];
                hist(cond).cell_cong_treino = [];
                hist(cond).cell_cong_classe_treino = [];
                hist(cond).qtd_congelado=[];
                hist(cond).p=[];

                %FIM do Algoritmo 
                separavel = 0;
                parou = cond;
                cond = cond_max;
            end        
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
end

%%%%%%% FIM ALGORITMO %%%%%%%%%%%%%%%% FIM ALGORITMO %%%%%%%%%%%%%%%% FIM ALGORITMO %%%%%%%%%%%%%%%% FIM ALGORITMO %%%%%%%%%%%%%%%%%%%%%%%%% FIM ALGORITMO %%%%%%%%%%%%%%%%%%%%%%%%% FIM ALGORITMO %%%%%%%%%%%%%%%%%%%%%%%%% FIM ALGORITMO %%%%%%%%%%%%%%%%%%%%%%%%% FIM ALGORITMO %%%%%%%%%%%%%%%%%%%%%%%%% FIM ALGORITMO %%%%%%%%%%%%%%%%%%%%%%%%% FIM ALGORITMO %%%%%%%%%


% Agrupa centros de todas as c�lulas congeladas
for i=1:(parou)
    if isempty(hist(i).c_cong) % se tiver vazio, fa�a nada.
    else
        if isnan(C_final) 
            C_final = hist(i).c_cong;
        else 
            C_final = vertcat(C_final,hist(i).c_cong);
        end
    end
end

% Agrupa agrupa erro minimo local de c�lulas congeladas
for i=1:(parou)
    if isempty(hist(i).erro_min) % se tiver vazio, fa�a nada.
    else
        if isnan(erro_min_final)
            erro_min_final = hist(i).erro_min;
            erro_min_final = erro_min_final';
        else 
            erro_min_final = vertcat(erro_min_final,(hist(i).erro_min)');
        end
    end
end

%%%% ERRO TOTAL FINAL %%%

y=0;
[prototipo_k,~] = size(C_final);
cel_treino_final = cell(prototipo_k,1);
cel_classe_treino_final = cell(prototipo_k,1);

for j=1:(length(hist)) 
    c_cong = hist(1, j).c_cong;
    if isempty(c_cong)
    else                       % para cada itera��o congelada 
        data_tr = hist(1, j).cell_cong_treino;
        classe_data_tr = hist(1, j).cell_cong_classe_treino;
        [lin_c,~] = size(c_cong);
        [qtd_obs,~] = size(data_tr);
        
        if lin_c==1
           ind = ones(qtd_obs,1);
        else
            distancias = dist(data_tr,c_cong');
            [~, ind]= min(distancias'); 
            ind = ind';
        end    
        for x=1:lin_c
            y=y+1;
            cel_treino_final{y}= data_tr(ind==x,:);
            cel_classe_treino_final{y}=classe_data_tr(ind==x,:);
        end
        
    end
end
disp('END');
erro_total =0;
obs_total=0;

tam_cel_final = zeros(prototipo_k,1);

for i=1:prototipo_k
    [linCel_teste, ~]= size(cel_treino_final{i});
    tam_cel_final(i)=linCel_teste;
end


for i=1:prototipo_k
    erro_total = (  tam_cel_final(i)*erro_min_final(i) ) + erro_total;
    obs_total = tam_cel_final(i)+obs_total;
end

taxa_erro_total_Insample = (erro_total)/(obs_total);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FIM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end