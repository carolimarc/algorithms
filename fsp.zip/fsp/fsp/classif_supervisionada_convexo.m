function [contador_t,contador_e,nova_cel_classe_teste,risk_value]= classif_supervisionada_convexo(q,Prop1,Prop2,MClasse1,MClasse2,cel_teste,cel_classe_teste,max_vero,min_vero,p)
%LOG: acrescentado contador_t e contador_e para celulas homogeneas
%LOG 16/04/2015: adicionado threshold para evitar 


%DEFINI��O: Fun��o que faz uma classifica��o supervisionada de uma c�lula teste (observa��es do conjunto teste que cairam em
%uma dada celula) a partir de par�metros da c�lula treino, devolvendo erro
%total e a classifica��o final. Utiliza combina��o convexa entre os
%parametros de propor��o e verossimilhan�a. Aplic�vel em R2

%INPUT:
    % Valor atual de Q: q
    % Quantidade de c�lulas / prototipos: prototipo_k
    % Propor��o classe 1 celula treino: Prop1
    % Propor��o classe 2 celula treino: Prop2
    % Centro euclidiano classe 1 celula treino: MClasse1
    % Centro euclidiano classe 2 celula treino: MClasse2
    % Celula de teste e classe da celula de teste de entrada
    % Verossimelhan�a m�xima e m�nima dentro de cada c�lula: max_vero e
    % min_vero
%OUTPUT: 
    % Contador de observa��es que cairam na c�lula heterog�nea: contador_t
    % Contador de observa��es classificadas erradas dentro da c�lula heterog�nea: contador_e
    % Vetor de classes classificadas pelo algoritmo: nova_cel_classe_teste
    

%Inicializa��o Par�metros
contador_t = 0;
contador_e = 0;
[lin_cel_teste, ~]= size(cel_teste);
threshold = p;

nova_cel_classe_teste = zeros(lin_cel_teste,1);
risk_value = zeros(lin_cel_teste,1);
vero_temp1 = zeros(lin_cel_teste,1);
vero_temp2 = zeros(lin_cel_teste,1);
vero_norm1 = zeros(lin_cel_teste,1);
vero_norm2 = zeros(lin_cel_teste,1);
prod_temp1 = zeros(lin_cel_teste,1);
prod_temp2 = zeros(lin_cel_teste,1);

% Algoritmo de Classifica��o

for i=1:lin_cel_teste

    if (Prop1 == 1) || (Prop2 <= threshold) %verifica se � homogenea para classe 1 
        nova_cel_classe_teste(i) = 1; %classifica nova observa��o como classe 1
        risk_value(i) = Prop1;
        contador_t = lin_cel_teste;
        if (nova_cel_classe_teste(i) ~= cel_classe_teste(i))
            contador_e = contador_e +1;
        end;      
    end

    if (Prop2 == 1) || (Prop1 <= threshold) %verifica se � homogenea para classe 2
        nova_cel_classe_teste(i) = 2; %classifica nova observa��o como classe 2 
        risk_value(i) = Prop2;
        contador_t = lin_cel_teste;
        if (nova_cel_classe_teste(i) ~= cel_classe_teste(i))
            contador_e = contador_e +1;
        end; 
    end

    if (Prop1 ~= 1) && (Prop2 ~= 1) && (Prop1 > threshold) &&  (Prop2 > threshold)% caso c�lula heterog�nea

        distancias_classe(1,:) = dist(cel_teste(i,:),MClasse1'); %distancia da observa��o do data_teste para cada centro de classe = 1 dentro de cada celula. 
        distancias_classe(2,:) = dist(cel_teste(i,:),MClasse2'); %distancia da observa��o do data_teste para cada centro de classe = 1 dentro de cada celula
        vero_temp1(i) = (1/distancias_classe(1,:)); %verossimilhan�a da classe = 1 
        vero_temp2(i) = (1/distancias_classe(2,:)); %verossimilhan�a da classe = 2 

        if max_vero ~= min_vero
            vero_norm1(i) = (vero_temp1(i) - min_vero)/(max_vero - min_vero); % verossimilhan�a classe 1 normalizada 
            vero_norm2(i) = (vero_temp2(i) - min_vero)/(max_vero - min_vero); % verossimilhan�a classe 2 normalizada 
        else
            vero_norm1(i) = vero_temp1(i);
            vero_norm2(i) = vero_temp2(i); 
        end
            
        prod_temp1(i)= (vero_norm1(i)^(1-q))*((Prop1)^q); % combina��o convexa Q=1 Somente a propor��o ser� levada em conta; Q=0 Somente a verossimilhan�a ser� levada em conta
        prod_temp2(i)= (vero_norm2(i)^(1-q))*((Prop2)^q); % combina��o convexa Q=1 Propor��o ser� levada em conta; Q=0 Somente a verossimilhan�a ser� levada em conta

        if ( prod_temp1(i) >= prod_temp2(i) ) %regra de decis�o caso c�lula heterog�nea 
            %nova_cel_classe_teste(i) = randsample([1,2],1,true,[Prop1, Prop2]); %se quiser que Prop seja probabilidade
            nova_cel_classe_teste(i) = 1;
            risk_value(i) = prod_temp1(i);
        elseif ( prod_temp2(i) > prod_temp1(i) )
            %nova_cel_classe_teste(i) = randsample([1,2],1,true,[Prop1, Prop2]); %se quiser que Prop seja probabilidade
            nova_cel_classe_teste(i) = 2;
            risk_value(i) = prod_temp2(i);
        end;
        

        contador_t = contador_t +1;

        if (nova_cel_classe_teste(i) ~= cel_classe_teste(i))
            contador_e = contador_e +1;
        end;
    end;

end;
    
end

    
    









